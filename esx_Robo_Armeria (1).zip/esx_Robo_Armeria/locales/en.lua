Locales['en'] = {

	['robbery_cancelled'] = 'el robo ha sido cancelado!',
	['shop_robbery'] = 'Robo a tienda de armas',
	['press_to_rob'] = 'Dispara para iniciar el robo',
	['seconds_remaining'] = '~w~ segundos restantes',
	['robbery_cancelled_at'] = '~r~ el robo ha sido cancelado en: ~b~',
	['robbery_has_cancelled'] = '~r~ el robo ha sido cancelado: ~b~',
	['already_robbed'] = 'la tienda de armas ya ha sido robada. Espere: ',
	['seconds'] = 'segundos.',
	['rob_in_prog'] = '~r~ robo en curso en: ~b~',
	['started_to_rob'] = 'Tu comenzaste el robo ',
	['do_not_move'] = ', saca las armas de las ventanas!',
	['alarm_triggered'] = 'la alarma se ha disparado',
	['hold_pos'] = 'cuando hayas recogido todas las armas, huye!',
	['robbery_complete'] = '~r~ ¡El robo ha tenido éxito! ~ s ~ ~ h ~ Huye! ',
	['robbery_complete_at'] = '~r~ El robo ha tenido éxito en: ~b~',
	['min_two_police'] = 'debe haber al menos ~b~',
	['min_two_police2'] = ' ~w~policías en la ciudad para robar.',
	['robbery_already'] = '~r~Ya se está produciendo un robo.',
	['robbery_has_ended'] = 'Robo terminado',
	['end'] = 'La tienda de armas ha sido robada!',
	['field'] = 'Pulsa ~y~ E ~s~ para ~o~ recoger ~s~ las armas',
	['press_to_collect'] = 'recoger armas',
	['collectinprogress'] = 'Recogiendo armas...',
	['smash_case'] = 'ventanas rotas',
	['need_bag'] = '¡Necesitas la bolsa! Ir a la tienda de ropa más cercana.'

}
