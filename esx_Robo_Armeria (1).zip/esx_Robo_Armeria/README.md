# esx_weaponshop_robbery
ESX Weaponshop Robbery V 2.0.0

[REQUIREMENTS]

  * esx_policejob => https://github.com/ESX-Org/esx_policejob
  * esx_ambulancejob => https://github.com/ESX-Org/esx_ambulancejob

[INSTALLATION]

1) CD in your resources/[esx] folder
2) Clone the repository
3) Add this in your server.cfg :

```
start esx_weaponshop_robbery
```

[ORIGINAL SCRIPT]

  * esx_vangelico_robbery => https://github.com/ESX-PUBLIC/esx_vangelico_robbery 

[VIDEO]

  * https://streamable.com/dpv0ui


