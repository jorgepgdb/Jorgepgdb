Config = {}
Config.Locale = 'en'

Config.RequiredCopsRob = 6
Config.MaxWindows = 10
Config.SecBetwNextRob = 1800 --1 hour
Config.EnableMarker = true
Config.NeedBag = false


Stores = {
	["WeaponShop"] = {
		position = { ['x'] = 814.94, ['y'] = -2157.7, ['z'] = 29.62 },       
		nameofstore = "Tienda de armas",
		lastrobbed = 0
	}
}

Items = {
	"WEAPON_SNSPISTOL",
	"WEAPON_HEAVYPISTOL",
	"WEAPON_KNIFE",
	"weapon_ASSAULTRIFLE",
	"weapon_MICROSMG",
	"weapon_KNIFE",
	"weapon_SNSPISTOL",
	"weapon_HEAVYPISTOL",
	"weapon_COMBATPISTOL"
}


